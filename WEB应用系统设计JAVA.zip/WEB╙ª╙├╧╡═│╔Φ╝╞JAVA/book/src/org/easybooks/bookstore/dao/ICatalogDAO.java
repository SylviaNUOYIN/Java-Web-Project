package org.easybooks.bookstore.dao;
import java.util.List;
public interface ICatalogDAO {
	public List getAllCatalogs();
}
